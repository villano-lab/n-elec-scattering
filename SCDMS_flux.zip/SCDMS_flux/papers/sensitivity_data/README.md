# Sensitivity Data

Sensitivity data in this directory is taken from the following paper:

SuperCDMS Collaboration, October 4, 2016. Projected Sensitivity of the SuperCDMS SNOLAB experiment. [arXiv:1610.00006](https://arxiv.org/abs/1610.00006), [DOI:10.1103/PhysRevD.95.082002](https://doi.org/10.1103/PhysRevD.95.082002).

The plots used for data extraction, as well as the paper itself, have been moved to this directory.
